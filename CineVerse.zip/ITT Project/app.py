from flask import Flask, render_template, redirect,request, session
from flask_sqlalchemy import SQLAlchemy
from flask_session import Session
import requests
import uuid
import random
import bcrypt
app = Flask(__name__)
app.config["SESSION_PERMANENT"] = False
app.config["SESSION_TYPE"] = "filesystem"
Session(app)
app.config['SQLALCHEMY_DATABASE_URI'] = "postgresql://postgres:admin@localhost:5432/cineverse"
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class User(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(25), unique=True, nullable=False)
    email = db.Column(db.String(50), unique=True, nullable=False)
    password = db.Column(db.LargeBinary(250), nullable=False)
    dob=db.Column(db.String(15))
    
class Movies(db.Model):
    rank=db.Column(db.Integer, primary_key=False)
    title=db.Column(db.String(20), nullable=False)
    thumbnail=db.Column(db.String(250))
    rating=db.Column(db.String(10))
    id=db.Column(db.String(10), primary_key=True)
    year=db.Column(db.Integer)
    image=db.Column(db.String(300))
    bigimage=db.Column(db.String(300))
    description=db.Column(db.String(500))
    trailer=db.Column(db.String(200))
    trailerembed=db.Column(db.String(200))
    genre=db.Column(db.ARRAY(db.String(20)))
    director=db.Column(db.ARRAY(db.String(30)))
    writers=db.Column(db.ARRAY(db.String(30)))
    imdb_link=db.Column(db.String(70))

class Comment(db.Model):
    id=db.Column(db.Integer, primary_key=True, autoincrement=True)
    content=db.Column(db.String(200))
    email = db.Column(db.String(50), unique=True, nullable=False)
    movie=db.Column(db.String(20), nullable=False)

class Watchlist(db.Model):
    id=db.Column(db.Integer, primary_key=True, autoincrement=True)
    email = db.Column(db.String(50), unique=True, nullable=False)
    movie=db.Column(db.String(20), nullable=False)
    
    

def getMovie(movie):
    url = f"http://www.omdbapi.com/?t={movie}&type=movie&plot=fulls&apikey=18e7fd10"
    response = requests.get(url)
    data = response.json()
    movieData = {
        'title': data.get('Title', 'N/A'),
        'image': data.get('Poster', 'N/A'),
        'year':data.get('Released','N/A'),
        'rating':data.get('imdbRating','N/A'),
        'description':data.get('Plot','N/A'),
        'director':data.get('Director','N/A'),
        'writers':data.get('Writer','N/A'),
        'actors':data.get('Actors','N/A')
    }
    return movieData

@app.route('/')
def home():
    if not session.get("name"):
        return redirect("/login")
    else:
        return render_template('landingpage.html',user=session["name"])

@app.route('/about')
def about():
    return render_template('aboutpage.html')

@app.route('/login', methods=['POST','GET'])
def login():
    if request.method=='POST':
        username=request.form['username']
        password=request.form['password'].encode('utf-8')
        user = User.query.filter_by(name=username).first()
        
        if user and bcrypt.checkpw(password,user.password):
            session["name"]=username
            return redirect("/")
        else:
            return "Check Username/Password"
    else:
        return render_template('loginpage.html')
    
@app.route('/profile')
def viewprof():
    user=User.query.filter_by(name=session["name"]).first()
    watch=Watchlist.query.filter_by(email=user.email).all()
    return render_template('profile.html',prof=user,watchlist=watch)

@app.route('/forums')
def forums():
    return render_template('forums.html')
    

@app.route('/signup', methods=['POST','GET'])
def signup():
    if request.method=='POST':
        username = request.form['username']
        email = request.form['email']
        password = request.form['password']
        if User.query.filter_by(name=username).first() is not None:
            return 'Username is already taken.'
        elif User.query.filter_by(email=email).first() is not None:
            return'Email address is already registered.'
            
        salt = bcrypt.gensalt()
        hashed_password = bcrypt.hashpw(password.encode('utf-8'), salt)
        new_user = User(name=username, email=email, password=hashed_password)
        db.session.add(new_user)
        db.session.commit()
        session["name"]=username
        return render_template('landingpage.html',user=session["name"])
    else:
        return render_template('signup.html')
    
@app.route("/logout")
def logout():
    session["name"]=None
    return redirect("/")

@app.route('/movies/<movie_title>/addtowatchlist', methods=['POST'])
def add_to_watchlist(movie_title):
    # Check if the movie is already in the watchlist
    if not movie_in_watchlist(movie_title):
        # Add the movie to the watchlist
        user=User.query.filter_by(name=session["name"]).first().email
        watchlist_item = Watchlist(id=uuid.uuid4(),movie=movie_title,email=user)
        db.session.add(watchlist_item)
        db.session.commit()
    return redirect('/movies/'+movie_title)
def movie_in_watchlist(title):
    # Check if the movie is in the watchlist
    return Watchlist.query.filter_by(movie=title).first() is not None

@app.route('/movies/<movie_title>/removefromwatchlist', methods=['POST'])
def remove_from_watchlist(movie_title):
    # Check if the movie is in the watchlist
    watchlist_item = Watchlist.query.filter_by(movie=movie_title).filter_by(email=User.query.filter_by(name=session["name"]).first().email).first()
    if watchlist_item:
        # Remove the movie from the watchlist
        db.session.delete(watchlist_item)
        db.session.commit()
    return redirect('/movies/'+movie_title)

@app.route('/movies/<movie_name>',methods=['POST','GET'])
def moviedetails(movie_name):
    if request.method=='GET':
        email=User.query.filter_by(name=session["name"]).first().email
        watchlisted=''
        if(Watchlist.query.filter_by(movie=movie_name) is not None):
                if(Watchlist.query.filter_by(movie=movie_name).filter_by(email=email) is not None):
                    watchlisted=Watchlist.query.filter_by(movie=movie_name).filter_by(email=email).first()
        if(watchlisted is not None):
            watchlisted=Watchlist.query.filter_by(movie=movie_name).filter_by(email=email).first().movie
        print(watchlisted)
        movie = Movies.query.filter_by(title=movie_name).first()
        mcomment=Comment.query.filter_by(movie=movie_name).all()
        return render_template('moviedetails.html', movie=movie,comments=mcomment,ifwl=watchlisted)
    elif request.method=='POST':
        user=User.query.filter_by(name=session["name"]).first().email
        content=request.form["review"]
        print(content)
        movie=movie_name
        new_comment=Comment(id=uuid.uuid4(),movie=movie,content=content,email=user)
        db.session.add(new_comment)
        db.session.commit()
        return redirect('/movies/'+movie)

        
 
@app.route('/movies', methods=['POST','GET'])
def movies():
    if request.method=='GET':
        random_movies = []
    #    for i in range(78,101):
    #         url = "https://imdb-top-100-movies.p.rapidapi.com/top"+str(i)
    #         headers = {
    #             "X-RapidAPI-Key": "bd49e713eemshd6037d7bd735f1ap1ce0d7jsn3d879196a95f",
    #             "X-RapidAPI-Host": "imdb-top-100-movies.p.rapidapi.com"
    #         }
    #         response = requests.get(url, headers=headers)
    #         data=response.json()
    #         movieData = {
    #                 'rank':data.get('rank','N/A'),
    #                 'title': data.get('title', 'N/A'),
    #                 'image': data.get('image', 'N/A'),
    #                 'id':data.get('id','N/A'),
    #                 'thumbnail':data.get('thumbnail','N/A'),
    #                 'rating':data.get('rating','N/A'),
    #                 'description':data.get('description','N/A'),
    #                 'genre':data.get('genre','N/A'),
    #                 'director':data.get('director','N/A'),
    #                 'writers':data.get('writers','N/A'),
    #                 'year':data.get('year','N/A'),
    #                 'big_image':data.get('big_image','N/A'),
    #                 'imdb_link':data.get('imdb_link','N/A'),
    #                 'trailer_embed_link':data.get('trailer_embed_link','N/A')
    #             }
                
    #         print(movieData)
    #         #new_movie=Movies(rank=movieData.rank,title=movieData.title,bigImage=movieData.big_image,thumbnail=movieData.thumbnail,image=movieData.image,id=movieData.id,rating=movieData.rating, year=movieData.rating,description=movieData.description,genre=movieData.genre,director=movieData.director,writer=movieData.writers,trailerembed=movieData.trailer_embed_link,imbdlink=movieData.imdb_link)
    #         new_movie = Movies(
    #                 rank=movieData['rank'],
    #                 title=movieData['title'],
    #                 bigimage=movieData['big_image'],
    #                 thumbnail=movieData['thumbnail'],
    #                 image=movieData['image'],
    #                 id=movieData['id'],
    #                 rating=movieData['rating'],
    #                 year=movieData['year'],
    #                 description=movieData['description'],
    #                 genre=movieData['genre'],
    #                 director=movieData['director'],
    #                 writers=movieData['writers'],
    #                 trailerembed=movieData['trailer_embed_link'],
    #                 imdb_link=movieData['imdb_link']
    #             )
    #         db.session.add(new_movie)
    #         db.session.commit()
        random_movies=Movies.query.all()
        return render_template('movie.html', movies=random_movies)
    else:
        moviename=request.form['movie']
        searchResult=getMovie(moviename)
        return render_template('searchmoviedetails.html', movie=searchResult)

if __name__=="__main__":
    app.run(debug=True)